import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-hello',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './hello.component.html',
  styleUrls: ['./hello.component.css'],
})
export class HelloComponent {
  formData={
    name:'',
    email:'',
    message:''
  };
  submitForm(){
    console.log('Form Submitted',this.formData);
  }
}
